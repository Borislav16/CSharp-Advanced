﻿namespace BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> identifiables = new List<IIdentifiable>();
            List<IBirthable> birthabale = new List<IBirthable>();
            string command = string.Empty;
            while ((command = Console.ReadLine()) != "End")
            {
                
                string[] array = command.Split();
                if (array[0] == "Citizen")
                {
                    Citizen citizen = new Citizen(array[1], int.Parse(array[2]), array[3], array[4]);
                    identifiables.Add(citizen);
                    birthabale.Add(citizen);
                }
                else if (array[0] == "Robot")
                {
                    Robot robot = new Robot(array[1], array[2]);
                    identifiables.Add((robot));
                }
                else if (array[0] == "Pet")
                {
                    Pet pet = new Pet(array[1], array[2]);
                    birthabale.Add(pet);
                }
                
            }
            
            string givenYear = Console.ReadLine();
            foreach (var item in birthabale)
            {
                string[] array = item.Birthday.Split("/");
                if (array[2] == givenYear)
                {
                    Console.WriteLine(item.Birthday);
                }
            }
        }
    }
}