﻿namespace BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> identifiables = new List<IIdentifiable>();
            string command = string.Empty;
            while ((command = Console.ReadLine()) != "End")
            {
                
                string[] array = command.Split();
                if(array.Length == 3)
                {
                    Citizen citizen = new Citizen(array[0], int.Parse(array[1]), array[2]);
                    identifiables.Add(citizen);
                }
                else
                {
                    Robot robot = new Robot(array[0], array[1]);
                    identifiables.Add((robot));
                }
                
            }
            string fakeId = Console.ReadLine();
            foreach (var identifiable in identifiables)
            {
                if(identifiable.Id.EndsWith(fakeId))
                {
                    Console.WriteLine(identifiable.Id);
                }
            }
        }
    }
}