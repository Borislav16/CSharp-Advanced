﻿namespace Raiding.Core
{
    internal interface IHeroFactory
    {
    }
}