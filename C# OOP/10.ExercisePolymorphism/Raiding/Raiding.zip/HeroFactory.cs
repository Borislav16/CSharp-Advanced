﻿using Raiding.Core;

namespace Raiding
{
    internal class HeroFactory : IHeroFactory
    {
    }
}