﻿namespace Shapes
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Rectangle rectangle = new Rectangle(-4, 10);
            Circle circle = new Circle(3);

            Console.WriteLine(rectangle.Draw());
            Console.WriteLine($"Perimeter: {rectangle.CalculatePerimeter()}, Area: {rectangle.CalculateArea()}");

            Console.WriteLine(circle.Draw());
            Console.WriteLine($"Perimeter: {circle.CalculatePerimeter():F2}, Area: {circle.CalculateArea():F2}");
        }
    }
}