﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string classToInvestigate, params string[] fieldNames)
        {
            Type type = Type.GetType(classToInvestigate);

            FieldInfo[] fields = type.GetFields(BindingFlags.Public
                | BindingFlags.NonPublic
                | BindingFlags.Instance
                | BindingFlags.Static);

            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Class under investigation: {classToInvestigate}");

            object classInstance = Activator.CreateInstance(type, new object[] { });

            foreach ( var field in fields.Where(f => fieldNames.Contains(f.Name)))
            {
                string name = field.Name;
                object value = field.GetValue(classInstance);
            
            }

            return sb.ToString();
        }
    }
}
